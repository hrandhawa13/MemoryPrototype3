Harmanjit Randhawa


All the images and sound files should be in the same folder.
Protocols are in the Protocols file HTML file

How to run:
Put all the sound files, image files and script files in javaCode folder
Click on compileScript
Click on InitialRunScript
Once the game ends( By finishing game or pressing quit button),
close the JFrames for client windows, 
Click ServerAlreadyRunningScript